#include "LobotServoController.h"
#include <stdarg.h>
#include <string.h>

#define GET_LOW_BYTE(A) ((uint8_t)(A))
#define GET_HIGH_BYTE(A) ((uint8_t)((A) >> 8))

// �ؼ���ʹ�� UART5 �����߶�����ư�ͨ��
extern UART_HandleTypeDef huart5;

/* ȫ�ֱ������� */
bool isUartRxCompleted = false;
uint8_t LobotTxBuf[128];
uint8_t LobotRxBuf[32];
uint16_t batteryVolt;
uint16_t servoPositions[32];

/*********************************************************************************
 * Function:  moveServo
 * Description�� ���Ƶ������ת��
 **********************************************************************************/
void moveServo(uint8_t servoID, uint16_t Position, uint16_t Time)
{
	if (servoID > 31 || !(Time > 0)) {
		return;
	}
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = 8;
	LobotTxBuf[3] = CMD_SERVO_MOVE;
	LobotTxBuf[4] = 1;
	LobotTxBuf[5] = GET_LOW_BYTE(Time);
	LobotTxBuf[6] = GET_HIGH_BYTE(Time);
	LobotTxBuf[7] = servoID;
	LobotTxBuf[8] = GET_LOW_BYTE(Position);
	LobotTxBuf[9] = GET_HIGH_BYTE(Position);
	HAL_UART_Transmit(&huart5, LobotTxBuf, 10, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  moveServosByArray
 * Description�� ���ƶ�����ת��
 **********************************************************************************/
void moveServosByArray(LobotServo servos[], uint8_t Num, uint16_t Time)
{
	if (Num < 1 || Num > 32 || !(Time > 0)) {
		return;
	}
	uint8_t index = 7;
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = Num * 3 + 5;
	LobotTxBuf[3] = CMD_SERVO_MOVE;
	LobotTxBuf[4] = Num;
	LobotTxBuf[5] = GET_LOW_BYTE(Time);
	LobotTxBuf[6] = GET_HIGH_BYTE(Time);

	for (uint8_t i = 0; i < Num; i++) {
		LobotTxBuf[index++] = servos[i].ID;
		LobotTxBuf[index++] = GET_LOW_BYTE(servos[i].Position);
		LobotTxBuf[index++] = GET_HIGH_BYTE(servos[i].Position);
	}
	HAL_UART_Transmit(&huart5, LobotTxBuf, LobotTxBuf[2] + 2, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  runActionGroup
 * Description�� ����ָ��������
 **********************************************************************************/
void runActionGroup(uint8_t numOfAction, uint16_t Times)
{
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = 5;
	LobotTxBuf[3] = CMD_ACTION_GROUP_RUN;
	LobotTxBuf[4] = numOfAction;
	LobotTxBuf[5] = GET_LOW_BYTE(Times);
	LobotTxBuf[6] = GET_HIGH_BYTE(Times);
	HAL_UART_Transmit(&huart5, LobotTxBuf, 7, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  stopActionGroup
 * Description�� ֹͣ�������еĶ�����
 **********************************************************************************/
void stopActionGroup(void)
{
	LobotTxBuf[0] = FRAME_HEADER;
	LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = 2;
	LobotTxBuf[3] = CMD_ACTION_GROUP_STOP;
	HAL_UART_Transmit(&huart5, LobotTxBuf, 4, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  setActionGroupSpeed
 * Description�� �趨ָ��������������ٶ�
 **********************************************************************************/
void setActionGroupSpeed(uint8_t numOfAction, uint16_t Speed)
{
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = 5;
	LobotTxBuf[3] = CMD_ACTION_GROUP_SPEED;
	LobotTxBuf[4] = numOfAction;
	LobotTxBuf[5] = GET_LOW_BYTE(Speed);
	LobotTxBuf[6] = GET_HIGH_BYTE(Speed);
	HAL_UART_Transmit(&huart5, LobotTxBuf, 7, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  unloadServos
 * Description�� ���ƶ���������ж��
 **********************************************************************************/
void unloadServos(uint8_t Num, uint8_t servoIDs[])
{
	if (Num < 1 || Num > 32) return;
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = Num + 3;
	LobotTxBuf[3] = CMD_MULT_SERVO_UNLOAD;
	LobotTxBuf[4] = Num;
	for (uint8_t i = 0; i < Num; i++) {
		LobotTxBuf[5 + i] = servoIDs[i];
	}
	HAL_UART_Transmit(&huart5, LobotTxBuf, LobotTxBuf[2] + 2, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  readServoPositions
 * Description�� ��ȡ��������λ��
 **********************************************************************************/
void readServoPositions(uint8_t Num, uint8_t servoIDs[])
{
	if (Num < 1 || Num > 32) return;
	LobotTxBuf[0] = LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = Num + 3;
	LobotTxBuf[3] = CMD_MULT_SERVO_POS_READ;
	LobotTxBuf[4] = Num;
	for (uint8_t i = 0; i < Num; i++) {
		LobotTxBuf[5 + i] = servoIDs[i];
	}
	HAL_UART_Transmit(&huart5, LobotTxBuf, LobotTxBuf[2] + 2, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  getBatteryVoltage
 * Description�� ���ͻ�ȡ��ص�ѹ����
 **********************************************************************************/
void getBatteryVoltage(void)
{
	LobotTxBuf[0] = FRAME_HEADER;
	LobotTxBuf[1] = FRAME_HEADER;
	LobotTxBuf[2] = 2;
	LobotTxBuf[3] = CMD_GET_BATTERY_VOLTAGE;
	HAL_UART_Transmit(&huart5, LobotTxBuf, 4, HAL_MAX_DELAY);
}

/*********************************************************************************
 * Function:  receiveHandle
 * Description�� �Խ��յ�����������֡���д���
 **********************************************************************************/
void receiveHandle()
{
	if (isUartRxCompleted) {
		isUartRxCompleted = false;
		switch (LobotRxBuf[3]) {
		case CMD_GET_BATTERY_VOLTAGE:
			batteryVolt = (((uint16_t)(LobotRxBuf[5])) << 8) | (LobotRxBuf[4]);
			break;
		case CMD_MULT_SERVO_POS_READ:
			{
				uint8_t num_servos = LobotRxBuf[4];
				if (LobotRxBuf[2] == (num_servos * 3 + 3)) {
					for (uint8_t i = 0; i < num_servos; i++) {
						uint8_t servo_id = LobotRxBuf[5 + i * 3];
						if (servo_id < 32) {
							uint16_t pos = (((uint16_t)LobotRxBuf[5 + i * 3 + 2]) << 8) | LobotRxBuf[5 + i * 3 + 1];
							servoPositions[servo_id] = pos;
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}
}
