#include "mission_control.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "Raspberry.h"
#include "GM65.h"
#include "Motor_Control.h"
#include "LobotServoController.h"
#include "bus_servo_control.h"

// ================= �ⲿ�������� =================
extern uint8_t Read_bit;
extern uint16_t GM65_Read2[3];
extern volatile char g_rpi_full_result[32]; 
extern volatile uint8_t g_rpi_new_data_flag;
extern UART_HandleTypeDef huart3;

// ================= ȫ�ֱ������� =================
volatile MissionState_t g_mission_state = MISSION_STATE_IDLE;
volatile uint8_t g_vision_task_in_progress = 0;

char g_qr_code_string[4];
uint16_t move_time = 2500;
uint16_t hold_time = 500;

static uint32_t state_start_tick = 0; 

// ��ʱ����
#define BLIND_MOVE_TIMEOUT_MS   3000   
#define ALIGN_TIMEOUT_MS        30000  

// ���� �������� (�������ȷ�ϰ�) ����
#define K_GAIN              0.5f   
#define MIN_MOVE_MM         15     
#define MAX_MOVE_MM         120    
#define BOMB_C1_APPROACH_DISTANCE   275.0f

#define ALIGN_TOLERANCE     50     

// ���� ����2���� ����
#define TARGET_ADJUST_DISTANCE      50.0f  
#define LASER_FIRE_DURATION_MS      2000   

// ================= ��е����Ӳ�����ƺ��� =================
void Laser_On(void) { 
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_SET);
    printf("Laser ON\r\n");
}
void Laser_Off(void) { 
    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET);
    printf("Laser OFF\r\n");
}

// ���� ��е��ץȡ���� (����1) ����
void Arm_Start_Bomb_Grab(void) { 
    // 1. �ƶ���ץȡ��̬
    Servos_SetPositions((uint16_t[]){160, 590, 315, 605, 480, 200}, 1500); 
    HAL_Delay(move_time + hold_time); 
    
    // ��צ
    Servos_SetPositions((uint16_t[]){160, 330, 315, 605, 480, 200}, 1500); 
    HAL_Delay(move_time + hold_time); 

    // ��צ
    Servos_SetPositions((uint16_t[]){160, 330, 315, 605, 480, 410}, 1500); 
    HAL_Delay(move_time + hold_time); 
    
    // 2. �ָ�����ʼ��̬ (̧��)
    Servos_SetPositions((uint16_t[]){160, 590, 315, 605, 480, 410}, 1500);
    HAL_Delay(move_time + hold_time); 
}

// ���� ��е�۷��ö��� (����1) ����
void Arm_Start_Bomb_Place(void) { 
    // ����1
    Servos_SetPositions((uint16_t[]){915, 590, 315, 605, 480, 410}, move_time);
    HAL_Delay(move_time + hold_time);

    // ����2
    Servos_SetPositions((uint16_t[]){915, 330, 315, 605, 480, 410}, move_time); 
    HAL_Delay(move_time + hold_time); 
    
    // ��צ
    Servos_SetPositions((uint16_t[]){915, 330, 315, 605, 480, 200}, move_time); 
    HAL_Delay(move_time + hold_time); 
    
    // ��λ
    Servos_SetPositions((uint16_t[]){915, 590, 315, 605, 480, 200}, move_time); 
    HAL_Delay(move_time + hold_time); 
}

void Arm_Start_Rescue_Grab(void){ printf("Arm: Rescue Grab (TODO)\r\n"); }
void Arm_Start_Rescue_Retract(void){ printf("Arm: Rescue Retract (TODO)\r\n"); }

// ���� ��ʼ�� ����
void Mission_Init(void) { 
    g_mission_state = MISSION_STATE_IDLE; 
    g_vision_task_in_progress = 0; 
    Chassis_Stop(); 
    Laser_Off();
    // ��ʼ��̬: 160, 590, 315, 850, 480, 200
    Servos_SetPositions((uint16_t[]){160, 590, 315, 850, 480, 200}, 1500); 
    HAL_Delay(1500);
}

// ���� ������� ����
void Mission_Start(void)
{
    if (g_mission_state == MISSION_STATE_IDLE || g_mission_state == MISSION_STATE_COMPLETE) {
        printf("--- MISSION START ---\r\n");
        // Ĭ�ϴ�ͷ��ʼ (����뵥����������2���ĳ� STATE_12_PART1_MOVE_A)
        g_mission_state = STATE_1_MOVING_TO_QR_SCAN; 
    }
}

// ================= �Ӿ��������߼����� =================

int32_t Calculate_Move_Distance(int pixel_error)
{
    if (abs(pixel_error) < ALIGN_TOLERANCE) return 0; 

    int32_t dist = (int32_t)(abs(pixel_error) * K_GAIN);
    if (dist < MIN_MOVE_MM) dist = MIN_MOVE_MM; 
    if (dist > MAX_MOVE_MM) dist = MAX_MOVE_MM; 
    return dist;
}

static void Handle_Vision_Alignment(uint8_t expected_task_number)
{
    // --- ����1 ״̬���� ---
    typedef enum { 
        BOMB_IDLE, BOMB_WAIT_INITIAL_MOVE, BOMB_REQUEST_FINE_TUNE, 
        BOMB_WAIT_FINE_ALIGN, BOMB_PERFORM_GRAB, BOMB_ADJUST_FOR_PLACE, 
        BOMB_PERFORM_PLACE, BOMB_COMPLETE 
    } BombSubState_t;
    
    static BombSubState_t bomb_sub_state = BOMB_IDLE;
    static char bomb_path_taken = ' ';
    
    // --- ����2 ״̬���� ---
    typedef enum { 
        TARGET_IDLE, TARGET_WAIT_ADJUST, TARGET_FIRING, TARGET_COMPLETE 
    } TargetSubState_t;
    static TargetSubState_t target_sub_state = TARGET_IDLE;
    static char target_path_taken = ' ';
    static uint32_t laser_start_time = 0;

    // ���ñ���
    static uint16_t initial_move_timeout = 0; 
    static uint8_t vision_cooldown = 0; 
    static uint32_t align_start_time = 0;

    // ================= ���� 1: �ű� =================
    if (expected_task_number == 1) {
        switch(bomb_sub_state) {
            case BOMB_IDLE:
                if (!g_vision_task_in_progress) {
                    Chassis_Stop(); 
                    printf("TASK1: Vision Start\r\n");
                    RPi_Run_Specific_Task(1); 
                    g_vision_task_in_progress = 1; 
                } else {
                    if (g_rpi_new_data_flag) {
                        g_rpi_new_data_flag = 0; 
                        bomb_path_taken = g_rpi_full_result[0]; 
                        printf("Task1 Dir: %c\r\n", bomb_path_taken);
                        
                        if (bomb_path_taken == 'C') Chassis_Move_Forward(BOMB_C1_APPROACH_DISTANCE);
                        else if (bomb_path_taken == 'L') Chassis_Move_Backward(120); 
                        else if (bomb_path_taken == 'R') Chassis_Move_Forward(BOMB_C1_APPROACH_DISTANCE + 360);
                        
                        state_start_tick = HAL_GetTick();
                        bomb_sub_state = BOMB_WAIT_INITIAL_MOVE;
                    }
                }
                break;

            case BOMB_WAIT_INITIAL_MOVE:
                if (Chassis_Task_Is_Complete() || (HAL_GetTick() - state_start_tick > BLIND_MOVE_TIMEOUT_MS)) {
                    printf("Blind Move Done\r\n");
                    bomb_sub_state = BOMB_REQUEST_FINE_TUNE;
                }
                break;

            case BOMB_REQUEST_FINE_TUNE:
                printf("Request Fine Align\r\n");
                HAL_UART_Transmit(&huart3, (uint8_t*)"start_align\n", 12, 100);
                g_rpi_new_data_flag = 0; 
                state_start_tick = HAL_GetTick();
                align_start_time = HAL_GetTick();
                vision_cooldown = 0;
                Chassis_Stop(); 
                bomb_sub_state = BOMB_WAIT_FINE_ALIGN;
                break;

            case BOMB_WAIT_FINE_ALIGN:
                if (HAL_GetTick() - state_start_tick > ALIGN_TIMEOUT_MS) {
                    printf("Timeout! Force Grab\r\n");
                    Chassis_Stop(); bomb_sub_state = BOMB_PERFORM_GRAB; break;
                }
                if (HAL_GetTick() - align_start_time > 15000 && g_rpi_new_data_flag) {
                    printf("15s Limit! Force Grab\r\n");
                    Chassis_Stop(); bomb_sub_state = BOMB_PERFORM_GRAB; break;
                }

                if (g_rpi_new_data_flag) {
                    g_rpi_new_data_flag = 0; 
                    if (vision_cooldown > 0) { vision_cooldown--; break; }

                    char local_buf[32]; memset(local_buf, 0, 32);
                    strncpy(local_buf, (char*)g_rpi_full_result, 31);

                    if (strncmp(local_buf, "OK", 2) == 0) {
                        printf("Vision OK -> Grab\r\n");
                        Chassis_Stop(); bomb_sub_state = BOMB_PERFORM_GRAB;
                    } else {
                        char *pD = strstr(local_buf, "D:");
                        if (pD != NULL) {
                            int err_x = 0, err_y = 0;
                            char *pComma = strchr(pD, ',');
                            if (pComma) {
                                *pComma = '\0'; err_x = atoi(pD + 2); err_y = atoi(pComma + 1);
                                printf("Err: %d, %d\r\n", err_x, err_y);

                                if (abs(err_x) < ALIGN_TOLERANCE && abs(err_y) < ALIGN_TOLERANCE) {
                                     printf("Close Enough -> Grab\r\n");
                                     Chassis_Stop(); bomb_sub_state = BOMB_PERFORM_GRAB; break;
                                }

                                // ���� �������� (��X��Y) ����
                                if (abs(err_x) >= ALIGN_TOLERANCE) {
                                    int32_t d = Calculate_Move_Distance(err_x);
                                    if (d > 0) {
                                        printf("Fix X: %d\r\n", d);
                                        if (err_x < 0) Chassis_Move_Right(d); else Chassis_Move_Left(d);
                                        vision_cooldown = 8; 
                                    }
                                } else if (abs(err_y) >= ALIGN_TOLERANCE) {
                                    int32_t d = Calculate_Move_Distance(err_y);
                                    if (d > 0) {
                                        printf("Fix Y: %d\r\n", d);
                                        if (err_y < 0) Chassis_Move_Backward(d); else Chassis_Move_Forward(d);
                                        vision_cooldown = 8; 
                                    }
                                }
                            }
                        }
                    }
                }
                break;

            case BOMB_PERFORM_GRAB:
                printf("State: GRAB\r\n");
                Arm_Start_Bomb_Grab(); 
                
                if (bomb_path_taken == 'L') {
                    printf("Adj L -> Fwd 360\r\n");
                    Chassis_Move_Forward(360); bomb_sub_state = BOMB_ADJUST_FOR_PLACE;
                } else if (bomb_path_taken == 'R') {
                    printf("Adj R -> Bwd 360\r\n");
                    Chassis_Move_Backward(360); bomb_sub_state = BOMB_ADJUST_FOR_PLACE;
                } else {
                    printf("Adj C -> Place\r\n");
                    bomb_sub_state = BOMB_PERFORM_PLACE;
                }
                break;

            case BOMB_ADJUST_FOR_PLACE:
                if (Chassis_Task_Is_Complete()) bomb_sub_state = BOMB_PERFORM_PLACE;
                break;

            case BOMB_PERFORM_PLACE: 
                printf("State: PLACE\r\n");
                Arm_Start_Bomb_Place(); 
                bomb_sub_state = BOMB_COMPLETE; 
                break;

            case BOMB_COMPLETE: 
                printf("Task 1 Done\r\n");
                bomb_sub_state = BOMB_IDLE; 
                g_mission_state++; // ��ת����һ����״̬
                break;
                
            default: break;
        }
    }

    // ================= ���� 2: ��� =================
    else if (expected_task_number == 2) {
        switch(target_sub_state) {
            case TARGET_IDLE:
                if (!g_vision_task_in_progress) {
                    Chassis_Stop(); 
                    printf("TASK2: Vision Start\r\n");
                    RPi_Run_Specific_Task(2); 
                    g_vision_task_in_progress = 1; 
                } else {
                    if (g_rpi_new_data_flag) {
                        g_rpi_new_data_flag = 0; 
                        g_vision_task_in_progress = 0;
                        target_path_taken = g_rpi_full_result[0]; 
                        printf("Task2 Dir: %c\r\n", target_path_taken);
                        
                        if (target_path_taken == 'C') {
                            target_sub_state = TARGET_FIRING;
                            Laser_On();
                            laser_start_time = HAL_GetTick();
                        } else if (target_path_taken == 'L') {
                            Chassis_Move_Left(TARGET_ADJUST_DISTANCE); 
                            target_sub_state = TARGET_WAIT_ADJUST;
                        } else if (target_path_taken == 'R') {
                            Chassis_Move_Right(TARGET_ADJUST_DISTANCE); 
                            target_sub_state = TARGET_WAIT_ADJUST;
                        }
                    }
                }
                break;

            case TARGET_WAIT_ADJUST:
                if (Chassis_Task_Is_Complete()) {
                    printf("Adj Done. Fire!\r\n");
                    target_sub_state = TARGET_FIRING;
                    Laser_On();
                    laser_start_time = HAL_GetTick();
                }
                break;

            case TARGET_FIRING:
                if (HAL_GetTick() - laser_start_time > LASER_FIRE_DURATION_MS) {
                    Laser_Off();
                    printf("Fire Complete.\r\n");
                    target_sub_state = TARGET_COMPLETE;
                }
                break;

            case TARGET_COMPLETE:
                printf("Task 2 Done\r\n");
                target_sub_state = TARGET_IDLE;
                g_mission_state++; // ��ת����һ����״̬
                break;
        }
    }
}

void Mission_Update(void)
{
    static MissionState_t last_state = (MissionState_t)-1;
    if (g_mission_state != last_state) {
        printf("State: %d -> %d\r\n", last_state, g_mission_state);
        last_state = g_mission_state;
        
        // ״̬��ڶ���
        switch (g_mission_state) {
            // --- ����1 ǰ��·�� ---
            case STATE_1_MOVING_TO_QR_SCAN:  Chassis_Move_Forward(1600); break;
            case STATE_2_PERFORMING_QR_SCAN: Chassis_Stop(); break;
            
            case STATE_3_MOVE_LEFT_A:        Chassis_Move_Left(1420.0f); Chassis_Move_TopLeft(600.0f); break;
            case STATE_4_MOVE_TOPLEFT:       Turn_Angle(0.1); break; 
            case STATE_5_STOP_BEFORE_RAMP:   Chassis_Move_Forward(2275.0f); break;//���ٴ�
            case STATE_6_CROSSING_RAMP_A:    Turn_Angle(0.1); break;
            
            // STATE_7 �ֶ�
            case STATE_7_MOVE_LEFT_B:        Chassis_Move_Left(1035.0f); break; 
            case STATE_7A_INTERMEDIATE_STOP: Turn_Angle(0.1); break; 
            case STATE_7B_MOVE_LEFT_C:       Chassis_Move_Left(1070.0f); break; 
            
            case STATE_7A_HEADING_CORRECTION:Turn_Angle(0.1); break;
            case STATE_8_MOVE_FORWARD_A:     Chassis_Move_Forward(2365.0f); break;//ǰ��������
            case STATE_8A_ADJUST_RIGHT:      Chassis_Move_Right(190.0f); break;
            case STATE_9_TURN_FOR_BOMB:      Turn_Angle(-93); break;
            case STATE_9A_ADJUST_LEFT:       Chassis_Move_Left(125.0f); break;
            
            case STATE_10_APPROACH_BOMB:     Chassis_Move_Forward(1400.0f); break;
            case STATE_11_PERFORMING_BOMB_DISPOSAL: Chassis_Stop(); break; 
            
            // --- ����2 ·����� (1800mm �� 3 �� + 2 ��У��) ---
            case STATE_12_PART1_MOVE_A:     printf("P12-1: Fwd 600\r\n"); Chassis_Move_Forward(600.0f); break;
            case STATE_12_PART1_CORRECT_A:  printf("P12-2: Gyro\r\n"); Turn_Angle(-90); break;
            case STATE_12_PART1_MOVE_B:     printf("P12-3: Fwd 600\r\n"); Chassis_Move_Forward(600.0f); break;
            case STATE_12_PART1_CORRECT_B:  printf("P12-4: Gyro\r\n"); Turn_Angle(-90); break;
            case STATE_12_PART1_MOVE_C:     printf("P12-5: Fwd 600\r\n"); Chassis_Move_Forward(600.0f); break;

            // ����2 Turn (-91�� ���)
            case STATE_12_TURN_A:           printf("Turn A: -45\r\n"); Turn_Angle(-90); break;
            case STATE_12_TURN_B:           printf("Turn B: -46\r\n"); Turn_Angle(-90); break;

            // ����2 Part 2 (1850mm ���)
            case STATE_12_PART2_MOVE_A:     printf("P12-P2-1: Fwd 600\r\n"); Chassis_Move_Forward(600.0f); break;
            case STATE_12_PART2_CORRECT_A:  printf("P12-P2-2: Gyro\r\n"); Turn_Angle(-90); break;
            case STATE_12_PART2_MOVE_B:     printf("P12-P2-3: Fwd 600\r\n"); Chassis_Move_Forward(600.0f); break;
            case STATE_12_PART2_CORRECT_B:  printf("P12-P2-4: Gyro\r\n"); Turn_Angle(-90); break;
            case STATE_12_PART2_MOVE_C:     printf("P12-P2-5: Fwd 650\r\n"); Chassis_Move_Forward(650.0f); break;

            case STATE_13_PERFORMING_TARGETING: Chassis_Stop(); break;
            
            // --- ����3 ǰ�� ---
            case STATE_14_MOVE_FORWARD_B:       printf("Path: Fwd 550\r\n"); Chassis_Move_Forward(550.0f); break;
            case STATE_15_TURN_FOR_HOSTAGE:     printf("Path: Turn -180\r\n"); Turn_Angle(-180); break;
            
            default: break;
        }
    }

    // ״̬ά������ת
    switch(g_mission_state) {
        // --- ����1 ���� ---
        case STATE_1_MOVING_TO_QR_SCAN: if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_2_PERFORMING_QR_SCAN: 
            if(Read_bit==1){Read_bit=0; sprintf(g_qr_code_string,"%d%d%d",GM65_Read2[0],GM65_Read2[1],GM65_Read2[2]); printf("QR: %s\r\n",g_qr_code_string); RPi_Send_QRCode_Data(g_qr_code_string); g_mission_state++;} 
            break;
        
        case STATE_3_MOVE_LEFT_A:        if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_4_MOVE_TOPLEFT:       if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_5_STOP_BEFORE_RAMP:   if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_6_CROSSING_RAMP_A:    if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        
        // STATE_7 �ֶ�
        case STATE_7_MOVE_LEFT_B:        if(Chassis_Task_Is_Complete()) g_mission_state++; break; 
        case STATE_7A_INTERMEDIATE_STOP: if(Chassis_Task_Is_Complete()) g_mission_state++; break; 
        case STATE_7B_MOVE_LEFT_C:       if(Chassis_Task_Is_Complete()) g_mission_state = STATE_7A_HEADING_CORRECTION; break; 
        
        case STATE_7A_HEADING_CORRECTION:if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_8_MOVE_FORWARD_A:     if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_8A_ADJUST_RIGHT:      if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_9_TURN_FOR_BOMB:      if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_9A_ADJUST_LEFT:       if(Chassis_Task_Is_Complete()) g_mission_state++; break;

        case STATE_10_APPROACH_BOMB: if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_11_PERFORMING_BOMB_DISPOSAL: Handle_Vision_Alignment(1); break;

        // --- ����2 ·�������ת ---
        case STATE_12_PART1_MOVE_A:     if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART1_CORRECT_A:  if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART1_MOVE_B:     if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART1_CORRECT_B:  if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART1_MOVE_C:     if(Chassis_Task_Is_Complete()) g_mission_state++; break; // �� Turn A

        case STATE_12_TURN_A:           if(Chassis_Task_Is_Complete()) g_mission_state++; break; // �� Turn B
        case STATE_12_TURN_B:           if(Chassis_Task_Is_Complete()) g_mission_state++; break; // �� Part 2 A

        case STATE_12_PART2_MOVE_A:     if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART2_CORRECT_A:  if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART2_MOVE_B:     if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART2_CORRECT_B:  if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_12_PART2_MOVE_C:     if(Chassis_Task_Is_Complete()) g_mission_state = STATE_13_PERFORMING_TARGETING; break;

        case STATE_13_PERFORMING_TARGETING: Handle_Vision_Alignment(2); break;

        // --- ����3 ---
        case STATE_14_MOVE_FORWARD_B:       if(Chassis_Task_Is_Complete()) g_mission_state++; break;
        case STATE_15_TURN_FOR_HOSTAGE:     if(Chassis_Task_Is_Complete()) { printf("All Done.\r\n"); Chassis_Stop(); } break;

        default: break;
    }
}
