#ifndef MISSION_CONTROL_H_
#define MISSION_CONTROL_H_

#include "main.h"

// --- 1. �������п��ܵ�����״̬ ---
typedef enum {
    // --- ��ʼ����� ---
    MISSION_STATE_IDLE = 0,
    MISSION_STATE_COMPLETE,

    // --- �׶�һ��ɨ�벢ǰ���ű��� ---
    STATE_1_MOVING_TO_QR_SCAN,     
    STATE_2_PERFORMING_QR_SCAN,    

    STATE_3_MOVE_LEFT_A,           
    STATE_4_MOVE_TOPLEFT,          
    STATE_5_STOP_BEFORE_RAMP,      
    STATE_6_CROSSING_RAMP_A,       
    
    // STATE_7 �ֶ��߼�
    STATE_7_MOVE_LEFT_B,           
    STATE_7A_INTERMEDIATE_STOP,    
    STATE_7B_MOVE_LEFT_C,          

    STATE_7A_HEADING_CORRECTION,   

    STATE_8_MOVE_FORWARD_A,        
    STATE_8A_ADJUST_RIGHT,         

    // --- �׶ζ����ű����� ---
    STATE_9_TURN_FOR_BOMB,         
    STATE_9A_ADJUST_LEFT,          
    STATE_10_APPROACH_BOMB,        
    STATE_11_PERFORMING_BOMB_DISPOSAL, 

    // --- �׶������������� (���) ·����� ---
    
    // Part 1: 1800mm
    STATE_12_PART1_MOVE_A,      
    STATE_12_PART1_CORRECT_A,   
    STATE_12_PART1_MOVE_B,      
    STATE_12_PART1_CORRECT_B,   
    STATE_12_PART1_MOVE_C,      
    
    // Turn: -91�� (���)
    STATE_12_TURN_A,            // ת -45
    STATE_12_TURN_B,            // ת -46

    // Part 2: 1850mm (���)
    STATE_12_PART2_MOVE_A,      // 600
    STATE_12_PART2_CORRECT_A,   
    STATE_12_PART2_MOVE_B,      // 600
    STATE_12_PART2_CORRECT_B,   
    STATE_12_PART2_MOVE_C,      // 650

    STATE_13_PERFORMING_TARGETING,  

    // --- �׶��ģ���Ԯ���� ---
    STATE_14_MOVE_FORWARD_B,       
    STATE_15_TURN_FOR_HOSTAGE,     
    STATE_16_APPROACH_HOSTAGE,     
    STATE_17_PERFORMING_HOSTAGE_RESCUE, 

    // --- �׶��壺���� ---
    STATE_18_RETURNING_TO_BASE,    

} MissionState_t;

// ... (���ౣ�ֲ���) ...
extern volatile MissionState_t g_mission_state;
extern volatile uint8_t g_vision_task_in_progress;
extern char g_qr_code_string[4];
extern volatile char g_rpi_full_result[32];
extern volatile uint8_t g_rpi_new_data_flag;

void Mission_Init(void);
void Mission_Start(void);
void Mission_Update(void);
void Arm_Start_Bomb_Grab(void);
void Arm_Start_Bomb_Place(void);
void Laser_On(void);
void Laser_Off(void);

#endif /* MISSION_CONTROL_H_ */
