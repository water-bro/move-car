/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
// 可以在这里包含项目级的头文件，比如 pid.h
// 但为了清晰，我们在每个 .c 文件中单独包含所需的头文件
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
extern UART_HandleTypeDef huart2;
/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
// --- 声明全局硬件句柄 ---
// 使用 'extern' 关键字，让其他文件(如 motor.c, encoder.c)也能访问在 main.c 中定义的这些变量
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim6;
extern TIM_HandleTypeDef htim8;
extern UART_HandleTypeDef huart1;
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define AIN1_Pin GPIO_PIN_2
#define AIN1_GPIO_Port GPIOE
#define KEY_START_Pin GPIO_PIN_3
#define KEY_START_GPIO_Port GPIOE
#define BIN1_Pin GPIO_PIN_4
#define BIN1_GPIO_Port GPIOE
#define BIN2_Pin GPIO_PIN_5
#define BIN2_GPIO_Port GPIOE
#define AIN2_Pin GPIO_PIN_6
#define AIN2_GPIO_Port GPIOE
#define CIN1_Pin GPIO_PIN_0
#define CIN1_GPIO_Port GPIOC
#define CIN2_Pin GPIO_PIN_1
#define CIN2_GPIO_Port GPIOC
#define DIN1_Pin GPIO_PIN_2
#define DIN1_GPIO_Port GPIOC
#define DIN2_Pin GPIO_PIN_3
#define DIN2_GPIO_Port GPIOC
#define E4A_Pin GPIO_PIN_0
#define E4A_GPIO_Port GPIOA
#define E4B_Pin GPIO_PIN_1
#define E4B_GPIO_Port GPIOA
#define E2A_Pin GPIO_PIN_6
#define E2A_GPIO_Port GPIOA
#define E2B_Pin GPIO_PIN_7
#define E2B_GPIO_Port GPIOA
#define PWMA_Pin GPIO_PIN_6
#define PWMA_GPIO_Port GPIOC
#define PWMB_Pin GPIO_PIN_7
#define PWMB_GPIO_Port GPIOC
#define PWMC_Pin GPIO_PIN_8
#define PWMC_GPIO_Port GPIOC
#define PWMD_Pin GPIO_PIN_9
#define PWMD_GPIO_Port GPIOC
#define E1A_Pin GPIO_PIN_15
#define E1A_GPIO_Port GPIOA
#define E1B_Pin GPIO_PIN_3
#define E1B_GPIO_Port GPIOB
#define E3A_Pin GPIO_PIN_6
#define E3A_GPIO_Port GPIOB
#define E3B_Pin GPIO_PIN_7
#define E3B_GPIO_Port GPIOB
#define jiguang_Pin GPIO_PIN_0
#define jiguang_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */
// TIM5 用于 Encoder D，其引脚通常是 PA0/PA1，请根据您的实际连接进行确认和添加
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
