#ifndef __HWT101_H
#define __HWT101_H
 
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "main.h"

extern volatile float global_angle;
extern volatile uint8_t new_data_received;
extern volatile float angular_velocity_y;
extern volatile float angular_velocity_z;
extern uint8_t received_data_packet[11];

void ParseAndPrintData(uint8_t *data, uint16_t length);
void HWT101_Init(void);

#endif

